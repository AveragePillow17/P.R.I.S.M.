*PADS-LIBRARY-PART-TYPES-V9*

USB3320C-EZK QFN50P500X500X100-33N-D I ANA 7 1 0 0 0
TIMESTAMP 2026.07.28.11.10.05
"Mouser Part Number" 886-USB3320C-EZK
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/USB3320C-EZK?qs=pA5MXup5wxEV58aAJyVneA%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" USB3320C-EZK
"Description" USB Interface IC Hi-Speed USB 2.0 ESD +30V Vbus
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/USB3320C-EZK.pdf
"Geometry.Height" 1mm
GATE 1 33 0
USB3320C-EZK
1 0 U CLKOUT
2 0 U NXT
3 0 U DATA0
4 0 U DATA1
5 0 U DATA2
6 0 U DATA3
7 0 U DATA4
8 0 U REFSEL0
9 0 U DATA5
10 0 U DATA6
11 0 U REFSEL1
12 0 U N/C
13 0 U DATA7
14 0 U REFSEL2
15 0 U SPK_L
16 0 U SPK_R
24 0 U RBIAS
23 0 U ID
22 0 U VBUS
21 0 U VBAT
20 0 U VDD33
19 0 U DM
18 0 U DP
17 0 U CPEN
33 0 U GND_FLAG
32 0 U VDDIO
31 0 U DIR
30 0 U VDD18_2
29 0 U STP
28 0 U VDD18_1
27 0 U RESETB
26 0 U REFCLK
25 0 U XO

*END*
*REMARK* SamacSys ECAD Model
309485/2068630/2.50/33/3/Integrated Circuit
