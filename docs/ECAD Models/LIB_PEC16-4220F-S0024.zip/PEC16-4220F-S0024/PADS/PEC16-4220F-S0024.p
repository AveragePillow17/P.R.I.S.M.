*PADS-LIBRARY-PART-TYPES-V9*

PEC16-4220F-S0024 PEC164120FS0012 I ANA 7 1 0 0 0
TIMESTAMP 2026.07.28.11.08.22
"Mouser Part Number" 652-PEC16-4220FS0024
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Bourns/PEC16-4220F-S0024?qs=6FD5PBp7ZtQte%252Bg7b%2FiMUw%3D%3D
"Manufacturer_Name" Bourns
"Manufacturer_Part_Number" PEC16-4220F-S0024
"Description" Bourns Encoder 24ppr ppr 5 V dc
"Datasheet Link" https://www.bourns.com/pdfs/PEC16.pdf
"Geometry.Height" 28mm
GATE 1 7 0
PEC16-4220F-S0024
A1 0 U A1
B1 0 U B1
C1 0 U C1
D1 0 U D1
E1 0 U E1
MH1 0 U MH1
MH2 0 U MH2

*END*
*REMARK* SamacSys ECAD Model
726287/2068630/2.50/7/4/Undefined or Miscellaneous
